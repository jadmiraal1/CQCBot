# Sentinel — Autonomous Search & Intercept UGV

Single Uno Q. Vision (Linux) gates and steers; MCU drives motors + reads range sensors.

## Mission logic (stop-look-pursue)
- ROTATE: spin in place a step (scan the room)
- SETTLE: STOP and hold still, then read camera motion (camera must be still for valid detection)
- detect a confirmed MOVING target within range -> PURSUE
- PURSUE: steer toward the target bearing (vision) while ToF/ultrasonic set forward speed; stop at standoff
- REACQUIRE: lost target -> spin to re-find; ARRIVED: hold at standoff until target leaves

## Why stop-look
A moving camera makes everything look like motion (ego-motion). So motion detection
only runs during the SETTLE (stopped) phase. This also spreads compute: vision during
stops, motors during motion.

## Safety
- ARM / STOP buttons on the dashboard.
- MCU stops motors if Python stops sending commands for 800ms (heartbeat dead-man switch).
- TEST WHEELS-UP FIRST. Confirm ARM/STOP and state transitions before floor runs.

## Run
Open http://<board-ip>:8790
- Live camera + motion overlay (partner's detector: rejects global light shifts, tracks speed/direction)
- Mission HUD: state, ToF/ultrasonic, bearing, motor outputs

## Tuning (top of python mission section)
DETECT_MM, US_DETECT_CM, STANDOFF_MM, PURSUE_MAX/MIN, TURN_SPEED, STEER_GAIN,
ROTATE_MS, SETTLE_MS. And vision thresholds near top of file (COLOR_DELTA_THRESHOLD etc).

## Notes
- Ultrasonic single-pin P9: if it reads -1, detection still works on ToF + vision.
- Modulino distance uses available()/get(); IMU uses update()/getX/Y/Z.
