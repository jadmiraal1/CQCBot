#include "Arduino_RouterBridge.h"
#include "Arduino_Modulino.h"

// ---- Motors (from working LaptopMovement) ----
const int LEFT_PWM = 5, RIGHT_PWM = 6;
const int LEFT_DIRECTION = 7, RIGHT_DIRECTION = 8;
const int MOTOR_STANDBY = 3;

// ---- Ultrasonic (single-pin P9) ----
const int ULTRASONIC_PIN = 9;
const unsigned long ECHO_TIMEOUT_US = 30000;
volatile int lastUsCm = -1;
unsigned long lastUsMs = 0;
const unsigned long US_INTERVAL_MS = 70;

// ---- Modulinos ----
ModulinoDistance distance;
ModulinoMovement movement;
bool distanceOk = false, movementOk = false, tried = false;
volatile int lastMm = -1;
volatile float lastAx=0, lastAy=0, lastAz=0;
volatile int lastImuOk = 0;
unsigned long lastMdMs=0, lastImuMs=0;
const unsigned long MD_INTERVAL_MS=60, IMU_INTERVAL_MS=40;

// ---- Safety: stop if no command from Python ----
unsigned long lastCmdMs = 0;
const unsigned long CMD_TIMEOUT_MS = 800;

String control(String command);
void setMotorPair(int pwmPin, int dirPin, int speed);
void driveLR(int l, int r);
void stopMotors();
float measureUsCm();

void setup() {
  pinMode(LEFT_PWM,OUTPUT); pinMode(RIGHT_PWM,OUTPUT);
  pinMode(LEFT_DIRECTION,OUTPUT); pinMode(RIGHT_DIRECTION,OUTPUT);
  pinMode(MOTOR_STANDBY,OUTPUT);
  stopMotors(); digitalWrite(MOTOR_STANDBY,HIGH);
  Bridge.begin(); Monitor.begin();
  Bridge.provide_safe("control", control);
  Monitor.println("Sentinel MCU ready");
}

void loop() {
  if (!tried) {
    tried = true;
    Modulino.begin(Wire1);
    distanceOk = distance.begin();
    movementOk = movement.begin();
    Monitor.print("distanceOk="); Monitor.println(distanceOk);
    Monitor.print("movementOk="); Monitor.println(movementOk);
  }
  unsigned long now = millis();

  // ULTRASONIC DISABLED FOR NOW: pulseIn() blocking was suspected of starving
  // the Modulino reads / bridge. Re-enable only after confirming Modulinos read.
  // if (now - lastUsMs >= US_INTERVAL_MS) {
  //   lastUsMs = now;
  //   float c = measureUsCm();
  //   lastUsCm = (c < 0) ? -1 : (int)c;
  // }
  lastUsCm = -1;
  if (distanceOk && now - lastMdMs >= MD_INTERVAL_MS) {
    lastMdMs = now;
    if (distance.available()) lastMm = (int)distance.get();
  }
  if (movementOk && now - lastImuMs >= IMU_INTERVAL_MS) {
    lastImuMs = now;
    if (movement.update()==1){ lastAx=movement.getX(); lastAy=movement.getY(); lastAz=movement.getZ(); lastImuOk=1; }
  }

  // safety stop if Python went quiet
  if (now - lastCmdMs > CMD_TIMEOUT_MS) stopMotors();
}

// command formats:
//   "ping"            -> just telemetry (does NOT change motors, but refreshes link)
//   "drive,<l>,<r>"   -> set motor speeds (-255..255), refreshes link
//   "stop"            -> stop motors
String control(String command) {
  lastCmdMs = millis();
  if (command == "stop") {
    stopMotors();
  } else if (command.startsWith("drive,")) {
    int c1 = command.indexOf(',');
    int c2 = command.indexOf(',', c1+1);
    if (c2 > c1) {
      int l = command.substring(c1+1, c2).toInt();
      int r = command.substring(c2+1).toInt();
      driveLR(l, r);
    }
  }
  // "ping" falls through to telemetry only

  float dist = 0;
  if (lastImuOk) { float m=sqrtf(lastAx*lastAx+lastAy*lastAy+lastAz*lastAz); dist=fabsf(m-1.0f); }
  return "md_mm=" + String(lastMm)
       + " us_cm=" + String(lastUsCm)
       + " imu_ok=" + String(lastImuOk)
       + " imu_dist=" + String(dist,3);
}

void driveLR(int l, int r) {
  l = constrain(l,-255,255); r = constrain(r,-255,255);
  digitalWrite(MOTOR_STANDBY,HIGH);
  setMotorPair(LEFT_PWM,LEFT_DIRECTION,l);
  setMotorPair(RIGHT_PWM,RIGHT_DIRECTION,r);
}
void setMotorPair(int pwmPin,int dirPin,int speed){
  digitalWrite(dirPin, speed>=0?HIGH:LOW);
  analogWrite(pwmPin, abs(speed));
}
void stopMotors(){ analogWrite(LEFT_PWM,0); analogWrite(RIGHT_PWM,0); }

float measureUsCm(){
  pinMode(ULTRASONIC_PIN,OUTPUT);
  digitalWrite(ULTRASONIC_PIN,LOW); delayMicroseconds(2);
  digitalWrite(ULTRASONIC_PIN,HIGH); delayMicroseconds(10);
  digitalWrite(ULTRASONIC_PIN,LOW);
  pinMode(ULTRASONIC_PIN,INPUT);
  unsigned long d=pulseIn(ULTRASONIC_PIN,HIGH,ECHO_TIMEOUT_US);
  if(d==0) return -1;
  return d/58.0;
}
