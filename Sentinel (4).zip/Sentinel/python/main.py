import atexit
import glob
import json
import math
import os
import signal
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from arduino.app_utils import App, Bridge

HOST = "0.0.0.0"
PORT = 8790

CAMERA_INDEXES = range(0, 6)
CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480
CAMERA_FPS = 30

TARGET_ANALYSIS_FPS = 10.0
ANALYSIS_INTERVAL_SECONDS = 1.0 / TARGET_ANALYSIS_FPS
PROCESS_WIDTH = 320

COLOR_DELTA_THRESHOLD = 42.0
MIN_CONTOUR_AREA_PX = 90
GLOBAL_CHANGE_PERCENT = 55.0
MOTION_MEMORY_FRAMES = 2

RUNTIME_DIR = "/tmp/sentinel"
FRAME_PATH = os.path.join(RUNTIME_DIR, "frame.jpg")
STATUS_PATH = os.path.join(RUNTIME_DIR, "status.json")
PID_PATH = os.path.join(RUNTIME_DIR, "worker.pid")
LOG_PATH = os.path.join(RUNTIME_DIR, "worker.log")
WORKER_ARG = "--motion-worker"

motion_worker = None
motion_worker_lock = threading.Lock()

INDEX_HTML = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MotionDetectionTest</title>
  <style>
    :root {
      color-scheme: dark;
      font-family: Arial, sans-serif;
      background: #0e1416;
      color: #eef7f4;
    }
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      min-height: 100vh;
      background: #0e1416;
    }
    main {
      width: min(96vw, 1120px);
      margin: 0 auto;
      padding: 22px 0;
      display: grid;
      gap: 14px;
    }
    header {
      display: flex;
      align-items: end;
      justify-content: space-between;
      gap: 12px;
    }
    h1 {
      margin: 0;
      font-size: 28px;
    }
    .status-pill {
      min-width: 112px;
      border: 1px solid #34474e;
      border-radius: 8px;
      padding: 8px 10px;
      text-align: center;
      font-weight: 700;
      background: #182126;
      color: #9caeb5;
    }
    .status-pill.moving {
      border-color: #7ee2b8;
      color: #07120e;
      background: #7ee2b8;
    }
    .status-pill.global {
      border-color: #ffc857;
      color: #171002;
      background: #ffc857;
    }
    .layout {
      display: grid;
      grid-template-columns: minmax(0, 1.45fr) minmax(280px, 0.55fr);
      gap: 14px;
      align-items: start;
    }
    .viewer {
      border: 1px solid #34474e;
      border-radius: 8px;
      background: #050708;
      overflow: hidden;
      aspect-ratio: 4 / 3;
      display: grid;
      place-items: center;
    }
    img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      display: block;
    }
    .panel {
      border: 1px solid #34474e;
      border-radius: 8px;
      background: #182126;
      padding: 14px;
      display: grid;
      gap: 12px;
    }
    .metric-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 10px;
    }
    .metric {
      border: 1px solid #293a40;
      border-radius: 7px;
      background: #11191d;
      padding: 10px;
      min-height: 76px;
      display: grid;
      align-content: center;
      gap: 4px;
    }
    .label {
      color: #9fb3ba;
      font-size: 12px;
      text-transform: uppercase;
    }
    .value {
      color: #eef7f4;
      font-size: 24px;
      font-weight: 700;
      line-height: 1.05;
      overflow-wrap: anywhere;
    }
    .small {
      font-family: Consolas, monospace;
      font-size: 13px;
      color: #b7c8ce;
      line-height: 1.45;
      overflow-wrap: anywhere;
    }
    button {
      width: fit-content;
      border: 1px solid #536970;
      border-radius: 6px;
      padding: 8px 12px;
      background: #203039;
      color: #eef5f7;
      cursor: pointer;
      font-weight: 700;
    }
    button:disabled {
      opacity: 0.58;
      cursor: wait;
    }
    @media (max-width: 820px) {
      .layout {
        grid-template-columns: 1fr;
      }
      header {
        align-items: start;
      }
    }
  </style>
</head>
<body>
  <main>
    <header>
      <h1>MotionDetectionTest</h1>
      <div id="motion-pill" class="status-pill">STARTING</div>
    </header>
    <section style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:6px;">
      <button id="arm" style="background:#13351f;color:#7ee2b8;border-color:#2f7d4f;font-size:16px;">ARM</button>
      <button id="stop" style="background:#3a0f12;color:#ff8e94;border-color:#a8313a;font-size:16px;">STOP</button>
      <div class="status-pill" id="mstate">IDLE</div>
      <div class="small" id="mnote" style="flex:1;">disarmed</div>
    </section>
    <section style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:6px;font-family:Consolas,monospace;font-size:13px;color:#b7c8ce;">
      <span>ToF: <b id="md">--</b> mm</span>
      <span>US: <b id="us">--</b> cm</span>
      <span>Bearing: <b id="brg">--</b></span>
      <span>Motors L/R: <b id="mot">--</b></span>
    </section>
    <section class="layout">
      <div class="viewer">
        <img id="stream" src="/stream.mjpg" alt="Motion detection stream">
      </div>
      <aside class="panel">
        <div class="metric-grid">
          <div class="metric">
            <div class="label">Speed</div>
            <div id="speed" class="value">--</div>
          </div>
          <div class="metric">
            <div class="label">Direction</div>
            <div id="direction" class="value">--</div>
          </div>
          <div class="metric">
            <div class="label">Motion Area</div>
            <div id="area" class="value">--</div>
          </div>
          <div class="metric">
            <div class="label">Centroid</div>
            <div id="centroid" class="value">--</div>
          </div>
          <div class="metric">
            <div class="label">Frame Lock</div>
            <div id="fps" class="value">--</div>
          </div>
          <div class="metric">
            <div class="label">Color Delta</div>
            <div id="delta" class="value">--</div>
          </div>
        </div>
        <button id="reconnect" type="button">Reconnect Camera</button>
        <div id="details" class="small">Waiting for worker...</div>
      </aside>
    </section>
  </main>
  <script>
    const pillEl = document.getElementById("motion-pill");
    const speedEl = document.getElementById("speed");
    const directionEl = document.getElementById("direction");
    const areaEl = document.getElementById("area");
    const centroidEl = document.getElementById("centroid");
    const fpsEl = document.getElementById("fps");
    const deltaEl = document.getElementById("delta");
    const detailsEl = document.getElementById("details");
    const streamEl = document.getElementById("stream");
    const reconnectEl = document.getElementById("reconnect");

    function fmt(value, digits = 1) {
      return Number.isFinite(value) ? value.toFixed(digits) : "--";
    }

    function setPill(payload) {
      pillEl.classList.remove("moving", "global");
      if (!payload.ok) {
        pillEl.textContent = "ERROR";
        return;
      }
      if (payload.globalChange) {
        pillEl.textContent = "LIGHT SHIFT";
        pillEl.classList.add("global");
        return;
      }
      if (payload.moving) {
        pillEl.textContent = "MOVING";
        pillEl.classList.add("moving");
        return;
      }
      pillEl.textContent = payload.ready ? "IDLE" : "LOCKING";
    }

    async function pollStatus() {
      try {
        const response = await fetch(`/api/status?t=${Date.now()}`, { cache: "no-store" });
        const payload = await response.json();
        setPill(payload);

        if (!payload.ok) {
          speedEl.textContent = "--";
          directionEl.textContent = "--";
          areaEl.textContent = "--";
          centroidEl.textContent = "--";
          fpsEl.textContent = "--";
          deltaEl.textContent = "--";
          detailsEl.textContent = payload.error || "Worker error";
          return;
        }

        speedEl.textContent = `${fmt(payload.speedPxPerSecond)} px/s`;
        directionEl.textContent = payload.direction || "--";
        areaEl.textContent = `${fmt(payload.motionAreaPercent, 2)}%`;
        centroidEl.textContent = payload.centroid
          ? `${fmt(payload.centroid.x, 0)}, ${fmt(payload.centroid.y, 0)}`
          : "--";
        fpsEl.textContent = `${fmt(payload.actualAnalysisFps, 2)} / ${fmt(payload.targetAnalysisFps, 0)}`;
        deltaEl.textContent = `${fmt(payload.averageColorDelta, 1)} avg`;

        detailsEl.textContent =
          `source=${payload.source} ` +
          `frame=${payload.analysisFrame} ` +
          `resolution=${payload.width}x${payload.height}\\n` +
          `threshold=${payload.colorDeltaThreshold} ` +
          `maxDelta=${fmt(payload.maxColorDelta, 1)} ` +
          `targetArea=${fmt(payload.targetAreaPercent, 2)}%\\n` +
          `jitter=${fmt(payload.lockJitterMs, 1)}ms ` +
          `age=${fmt(payload.ageSeconds, 2)}s ` +
          `workerAlive=${payload.workerAlive}`;
      } catch (error) {
        pillEl.textContent = "NETWORK";
        detailsEl.textContent = `Network error: ${error}`;
      }
    }

    reconnectEl.addEventListener("click", async () => {
      reconnectEl.disabled = true;
      detailsEl.textContent = "Restarting camera worker...";
      try {
        await fetch(`/api/reconnect?t=${Date.now()}`, { cache: "no-store" });
      } catch (error) {
        detailsEl.textContent = `Reconnect request failed: ${error}`;
      }
      streamEl.src = `/stream.mjpg?t=${Date.now()}`;
      setTimeout(() => {
        reconnectEl.disabled = false;
        pollStatus();
      }, 1200);
    });

    document.getElementById("arm").addEventListener("click",()=>fetch("/api/arm?t="+Date.now(),{cache:"no-store"}));
    document.getElementById("stop").addEventListener("click",()=>fetch("/api/stop?t="+Date.now(),{cache:"no-store"}));

    async function pollMission(){
      try{
        const r=await fetch("/api/mission?t="+Date.now(),{cache:"no-store"});
        const m=await r.json();
        const ms=document.getElementById("mstate");
        ms.textContent=(m.armed?m.state:"DISARMED");
        ms.className="status-pill"+(m.state==="PURSUE"?" global":(m.state==="ARRIVED"?" moving":""));
        document.getElementById("mnote").textContent=m.note||"";
        document.getElementById("md").textContent=(m.md_mm<0?"--":m.md_mm);
        document.getElementById("us").textContent=(m.us_cm<0?"--":m.us_cm);
        document.getElementById("brg").textContent=(m.bearing||"--")+" ("+(m.x_norm??0)+")";
        document.getElementById("mot").textContent=m.left+" / "+m.right;
      }catch(e){}
    }

    pollStatus();
    setInterval(pollStatus, 250);
    pollMission();
    setInterval(pollMission, 150);
  </script>
</body>
</html>
"""



# ============================ MISSION COORDINATOR ============================
# Reads vision detections + commands the MCU over the Bridge.
# Stop-look-pursue: rotate a step, STOP and look for motion (camera must be still
# for valid detection), and on a confirmed moving target, pursue toward its bearing
# while ToF/ultrasonic govern approach speed and standoff.

# --- tuning ---
DETECT_MM      = 600     # ToF: target "in range" under this (mm)
US_DETECT_CM   = 120     # ultrasonic: long-range cue under this (cm)
STANDOFF_MM    = 120     # stop pursuit at this ToF distance (mm)
PURSUE_MAX     = 210
PURSUE_MIN     = 120
TURN_SPEED     = 120     # base scan speed
TURN_OUTER     = 130     # outer wheel (faster) -> drives a small CIRCLE instead of spin
TURN_INNER     = 70      # inner wheel (slower, same direction) -> gentle arc, saves tires
STEER_GAIN     = 55      # gentler steering correction (was 110 -> too violent)
ROTATE_MS      = 220     # SHORT rotate burst -> small rotation steps
SETTLE_MS      = 2000    # longer look window after blanking
SETTLE_BLANK_MS= 900     # longer: fully clear robot self-motion/blur before trusting vision
LOST_LIMIT     = 25      # ToF-based now; tolerate brief dropouts (~1.2s) before reacquiring
CONFIRM_NEED   = 4       # need more consistent motion reads -> rejects transient/self-motion

# --- lead pursuit (predictive interception) ---
LEAD_GAIN      = 0.006   # gentler lead (was 0.012)
LEAD_MAX       = 0.3     # tighter lead cap (was 0.5)
MIN_TARGET_SPEED = 8.0   # px/s: ignore motion slower than this (jitter / residual)

# Detection gating:
#   require_range=True  -> need vision motion AND a range sensor in range (strict fusion)
#   require_range=False -> vision motion ALONE can trigger pursuit (range only sets speed)
REQUIRE_RANGE  = False   # start permissive so detection actually fires; tighten later

mission_lock = threading.Lock()
mission = {
    "armed": False,
    "state": "IDLE",
    "md_mm": -1, "us_cm": -1, "imu_ok": 0, "imu_dist": 0.0,
    "bearing": "none", "x_norm": 0.0, "moving": False, "speed": 0.0,
    "left": 0, "right": 0, "note": "",
}

def mcu(cmd):
    try:
        return str(Bridge.call("control", cmd))
    except Exception as e:
        return f"error:{e}"

def parse_mcu(raw):
    out = {}
    import re as _re
    for k in ("md_mm","us_cm","imu_ok"):
        m=_re.search(rf"{k}=(-?\d+)", raw)
        if m: out[k]=int(m.group(1))
    m=_re.search(r"imu_dist=(-?[0-9.]+)", raw)
    if m: out["imu_dist"]=float(m.group(1))
    return out

def vision_now():
    # read the worker's latest detection from status file
    st = read_status()
    return st

def mission_loop():
    state = "IDLE"
    state_t = time.monotonic()
    confirm = 0
    lost = 0
    arrive_cnt = 0
    last_bearing = 0.0
    last_vhx = 0.0

    def go(state_name):
        nonlocal state, state_t, confirm, lost
        state = state_name
        state_t = time.monotonic()

    while True:
        time.sleep(0.05)  # ~20 Hz coordinator
        with mission_lock:
            armed = mission["armed"]

        # Always read MCU telemetry (also serves as heartbeat via "ping")
        tel = parse_mcu(mcu("ping"))
        v = vision_now()
        md = tel.get("md_mm", -1)
        us = tel.get("us_cm", -1)
        moving = bool(v.get("moving", False))
        bearing_x = float(v.get("x_norm", 0.0))
        v_speed = float(v.get("speedPxPerSecond", 0.0))
        v_dir = str(v.get("direction", "none"))
        # horizontal velocity sign: +1 moving right, -1 moving left, 0 otherwise
        v_hx = (1.0 if "right" in v_dir else (-1.0 if "left" in v_dir else 0.0)) * v_speed

        tof_in = (md is not None and 0 <= md <= DETECT_MM)
        us_in  = (us is not None and 0 <= us <= US_DETECT_CM)
        range_in = tof_in or us_in

        left = right = 0
        note = ""

        if not armed:
            mcu("stop"); state = "IDLE"; confirm = 0; lost = 0
        else:
            now = time.monotonic()
            inT = (now - state_t) * 1000.0

            if state == "IDLE":
                go("ROTATE")

            elif state == "ROTATE":
                # small forward CIRCLE (both wheels same direction, different speed)
                left, right = TURN_OUTER, TURN_INNER
                note = "scanning"
                if inT >= ROTATE_MS:
                    go("SETTLE")

            elif state == "SETTLE":
                left = right = 0                         # hold still so vision is valid
                if inT < SETTLE_BLANK_MS:
                    # ignore vision while residual motion/blur from the turn clears
                    note = "settling"
                    confirm = 0
                else:
                    note = "looking"
                    real_motion = moving and (v_speed >= MIN_TARGET_SPEED)
                    detect = (real_motion and range_in) if REQUIRE_RANGE else real_motion
                    if detect:
                        confirm += 1
                        last_bearing = bearing_x
                        last_vhx = v_hx
                        if confirm >= CONFIRM_NEED:
                            confirm = 0; lost = 0; go("PURSUE")
                    # at end of window with no confirmed target -> keep scanning
                    if state == "SETTLE" and inT >= SETTLE_MS:
                        confirm = 0
                        go("ROTATE")

            elif state == "PURSUE":
                note = "pursuing"
                # Debounce ARRIVED: require consecutive close reads + min pursue time.
                if md is not None and 0 <= md <= STANDOFF_MM and inT >= 350:
                    arrive_cnt += 1
                else:
                    arrive_cnt = 0
                if arrive_cnt >= 2:
                    arrive_cnt = 0
                    go("ARRIVED")
                else:
                    # During pursuit the CAMERA IS MOVING, so motion detection is
                    # unreliable for steering. We pursue using ToF distance and the
                    # bearing LOCKED AT ACQUISITION (do NOT keep updating it from the
                    # moving camera -- that caused the haywire steering).
                    #
                    # "Lost" is judged by ToF, not vision flicker: only give up if the
                    # rangefinder sees nothing for a sustained time.
                    if tof_in:
                        lost = 0
                        span = max(1, DETECT_MM - STANDOFF_MM)
                        over = max(0, min(span, (md - STANDOFF_MM)))
                        base = PURSUE_MIN + int((PURSUE_MAX - PURSUE_MIN) * over / span)
                    else:
                        lost += 1
                        if lost >= LOST_LIMIT:
                            go("REACQUIRE")
                        base = PURSUE_MIN

                    # Gentle correction toward the LOCKED acquisition bearing only.
                    # Decays toward straight as we approach, so it stops fishtailing.
                    steer = int(STEER_GAIN * last_bearing)
                    left  = base + steer
                    right = base - steer

            elif state == "REACQUIRE":
                left, right = TURN_OUTER, TURN_INNER
                note = "reacquiring"
                redetect = (moving and range_in) if REQUIRE_RANGE else moving
                if redetect:
                    last_bearing = bearing_x; last_vhx = v_hx
                    lost = 0; go("PURSUE")
                elif inT >= 1500:
                    go("ROTATE")

            elif state == "ARRIVED":
                left = right = 0
                note = "target reached"
                if not (md is not None and 0 <= md <= DETECT_MM):
                    go("ROTATE")   # target left -> resume scan

            # send drive command (clamped)
            left = max(-255, min(255, left))
            right = max(-255, min(255, right))
            if state in ("SETTLE","ARRIVED","IDLE"):
                mcu("stop")
            else:
                mcu(f"drive,{left},{right}")

        with mission_lock:
            mission.update({
                "armed": armed, "state": state,
                "md_mm": md if md is not None else -1,
                "us_cm": us if us is not None else -1,
                "imu_ok": tel.get("imu_ok",0), "imu_dist": tel.get("imu_dist",0.0),
                "bearing": v.get("bearing","none"), "x_norm": bearing_x,
                "moving": moving, "speed": v.get("speedPxPerSecond",0.0), "v_dir": v.get("direction","none"),
                "left": left, "right": right, "note": note,
            })


class MotionHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(INDEX_HTML.encode("utf-8"))
            return

        if self.path.startswith("/api/status"):
            self.write_json(read_status())
            return

        if self.path.startswith("/api/reconnect"):
            restart_motion_worker("Manual reconnect requested")
            self.write_json(read_status())
            return

        if self.path.startswith("/api/arm"):
            with mission_lock:
                mission["armed"] = True
            self.write_json({"armed": True})
            return

        if self.path.startswith("/api/stop"):
            with mission_lock:
                mission["armed"] = False
            mcu("stop")
            self.write_json({"armed": False})
            return

        if self.path.startswith("/api/mission"):
            with mission_lock:
                self.write_json(dict(mission))
            return

        if self.path.startswith("/stream.mjpg"):
            self.stream_frames()
            return

        self.send_response(404)
        self.end_headers()

    def stream_frames(self):
        self.send_response(200)
        self.send_header("Age", "0")
        self.send_header("Cache-Control", "no-cache, private")
        self.send_header("Pragma", "no-cache")
        self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
        self.end_headers()

        while True:
            frame = read_frame()
            if frame is None:
                time.sleep(0.1)
                continue

            try:
                self.wfile.write(b"--frame\r\n")
                self.wfile.write(b"Content-Type: image/jpeg\r\n")
                self.wfile.write(f"Content-Length: {len(frame)}\r\n\r\n".encode("ascii"))
                self.wfile.write(frame)
                self.wfile.write(b"\r\n")
                time.sleep(0.05)
            except (BrokenPipeError, ConnectionResetError):
                break

    def write_json(self, payload, status=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def ensure_runtime_dir():
    os.makedirs(RUNTIME_DIR, exist_ok=True)


def read_frame():
    try:
        with open(FRAME_PATH, "rb") as frame_file:
            return frame_file.read()
    except OSError:
        return None


def read_status():
    status = {
        "ok": False,
        "ready": False,
        "error": "Motion worker is starting",
        "workerAlive": is_motion_worker_alive(),
    }
    try:
        with open(STATUS_PATH, "r", encoding="utf-8") as status_file:
            status.update(json.load(status_file))
    except OSError:
        pass

    status["workerAlive"] = is_motion_worker_alive()
    if "timestamp" in status:
        status["ageSeconds"] = round(time.time() - status["timestamp"], 2)
    return status


def write_status(payload):
    ensure_runtime_dir()
    payload = dict(payload)
    payload["timestamp"] = time.time()
    payload["workerPid"] = os.getpid()

    temp_path = STATUS_PATH + ".tmp"
    with open(temp_path, "w", encoding="utf-8") as status_file:
        json.dump(payload, status_file)
    os.replace(temp_path, STATUS_PATH)


def write_frame(frame_bytes):
    ensure_runtime_dir()
    temp_path = FRAME_PATH + ".tmp"
    with open(temp_path, "wb") as frame_file:
        frame_file.write(frame_bytes)
    os.replace(temp_path, FRAME_PATH)


def remove_runtime_file(path):
    try:
        os.remove(path)
    except FileNotFoundError:
        pass


def list_video_devices():
    devices = sorted(glob.glob("/dev/video*"))
    return sorted(devices, key=video_device_sort_key)


def video_device_sort_key(path):
    try:
        number = int(path.replace("/dev/video", ""))
    except ValueError:
        number = 0
    return (number < 2, number)


def start_motion_worker():
    global motion_worker

    ensure_runtime_dir()
    remove_runtime_file(FRAME_PATH)
    write_status({"ok": False, "ready": False, "error": "Starting motion worker"})

    command = [sys.executable, os.path.abspath(__file__), WORKER_ARG]
    log_file = open(LOG_PATH, "a", encoding="utf-8")
    try:
        motion_worker = subprocess.Popen(
            command,
            cwd=os.path.dirname(os.path.abspath(__file__)),
            stdin=subprocess.DEVNULL,
            stdout=log_file,
            stderr=log_file,
            close_fds=True,
            start_new_session=True,
        )
    finally:
        log_file.close()


def stop_motion_worker():
    global motion_worker

    if motion_worker is None or motion_worker.poll() is not None:
        return

    motion_worker.terminate()
    try:
        motion_worker.wait(timeout=1.5)
    except subprocess.TimeoutExpired:
        motion_worker.kill()
        try:
            motion_worker.wait(timeout=1.5)
        except subprocess.TimeoutExpired:
            pass


def restart_motion_worker(reason):
    with motion_worker_lock:
        write_status({"ok": False, "ready": False, "error": reason})
        stop_motion_worker()
        remove_runtime_file(FRAME_PATH)
        start_motion_worker()


def is_motion_worker_alive():
    return motion_worker is not None and motion_worker.poll() is None


def motion_worker_main():
    ensure_runtime_dir()
    with open(PID_PATH, "w", encoding="utf-8") as pid_file:
        pid_file.write(str(os.getpid()))

    write_status({"ok": False, "ready": False, "error": "Motion worker booting"})

    try:
        import cv2
        import numpy as np
    except Exception as error:
        write_status({"ok": False, "ready": False, "error": f"OpenCV import failed: {error}"})
        while True:
            time.sleep(5)

    while True:
        remove_runtime_file(FRAME_PATH)
        capture, source, tried = open_camera_for_worker(cv2)
        if capture is None:
            write_status({
                "ok": False,
                "ready": False,
                "error": "No readable camera. Tried: " + ", ".join(tried),
                "tried": tried,
            })
            time.sleep(1)
            continue

        state = {
            "previousFrame": None,
            "previousAnalysisTime": None,
            "previousMotionCentroid": None,
            "previousMotionTime": None,
            "missedMotionFrames": 0,
            "analysisFrame": 0,
        }

        next_analysis_at = time.monotonic()

        while True:
            scheduled_at = next_analysis_at
            wait_seconds = scheduled_at - time.monotonic()
            if wait_seconds > 0:
                time.sleep(wait_seconds)

            ok, frame = capture.read()
            captured_at = time.monotonic()
            if not ok or frame is None:
                write_status({
                    "ok": False,
                    "ready": False,
                    "error": f"Camera {source} stopped returning frames",
                    "source": str(source),
                })
                break

            state["analysisFrame"] += 1
            payload, overlay = analyze_frame(cv2, np, frame, source, state, captured_at, scheduled_at)
            encoded_ok, encoded = cv2.imencode(".jpg", overlay, [int(cv2.IMWRITE_JPEG_QUALITY), 82])
            if encoded_ok:
                write_frame(encoded.tobytes())

            write_status(payload)

            next_analysis_at += ANALYSIS_INTERVAL_SECONDS
            if next_analysis_at < captured_at - ANALYSIS_INTERVAL_SECONDS:
                next_analysis_at = captured_at + ANALYSIS_INTERVAL_SECONDS

        try:
            capture.release()
        except Exception:
            pass
        time.sleep(0.5)


def open_camera_for_worker(cv2):
    candidates = list_video_devices() + list(CAMERA_INDEXES)
    tried = [str(candidate) for candidate in candidates]

    for candidate in candidates:
        capture = open_capture(cv2, candidate)
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_WIDTH)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)
        capture.set(cv2.CAP_PROP_FPS, CAMERA_FPS)
        try:
            capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            pass

        if capture.isOpened() and has_readable_frame(capture):
            return capture, candidate, tried

        try:
            capture.release()
        except Exception:
            pass

    return None, None, tried


def open_capture(cv2, candidate):
    try:
        return cv2.VideoCapture(candidate, cv2.CAP_V4L2)
    except Exception:
        return cv2.VideoCapture(candidate)


def has_readable_frame(capture):
    for _ in range(8):
        ok, frame = capture.read()
        if ok and frame is not None:
            return True
        time.sleep(0.05)
    return False


def analyze_frame(cv2, np, frame, source, state, captured_at, scheduled_at):
    height, width = frame.shape[:2]
    process_height = max(1, round((PROCESS_WIDTH / width) * height))
    small = cv2.resize(frame, (PROCESS_WIDTH, process_height), interpolation=cv2.INTER_AREA)
    blurred = cv2.GaussianBlur(small, (5, 5), 0)
    current = blurred.astype(np.float32)

    previous = state["previousFrame"]
    state["previousFrame"] = current

    actual_fps = 0.0
    previous_time = state["previousAnalysisTime"]
    if previous_time is not None:
        elapsed = captured_at - previous_time
        if elapsed > 0:
            actual_fps = 1.0 / elapsed
    state["previousAnalysisTime"] = captured_at

    base_payload = {
        "ok": True,
        "ready": previous is not None,
        "moving": False,
        "globalChange": False,
        "source": str(source),
        "width": int(width),
        "height": int(height),
        "analysisFrame": state["analysisFrame"],
        "targetAnalysisFps": TARGET_ANALYSIS_FPS,
        "actualAnalysisFps": actual_fps,
        "lockJitterMs": max(0.0, (captured_at - scheduled_at) * 1000.0),
        "colorDeltaThreshold": COLOR_DELTA_THRESHOLD,
        "minContourAreaPx": MIN_CONTOUR_AREA_PX,
        "motionAreaPercent": 0.0,
        "targetAreaPercent": 0.0,
        "averageColorDelta": 0.0,
        "maxColorDelta": 0.0,
        "speedPxPerSecond": 0.0,
        "direction": "none",
        "centroid": None,
        "bbox": None,
        "x_norm": 0.0,
        "bearing": "none",
        "message": "Locking first comparison frame",
    }

    if previous is None:
        overlay = draw_overlay(cv2, frame.copy(), base_payload)
        return base_payload, overlay

    diff = current - previous
    color_delta = np.sqrt(np.sum(diff * diff, axis=2))
    raw_mask = (color_delta >= COLOR_DELTA_THRESHOLD).astype(np.uint8) * 255

    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.morphologyEx(raw_mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    valid_contours = [contour for contour in contours if cv2.contourArea(contour) >= MIN_CONTOUR_AREA_PX]

    filtered_mask = np.zeros_like(mask)
    if valid_contours:
        cv2.drawContours(filtered_mask, valid_contours, -1, 255, thickness=cv2.FILLED)

    total_pixels = float(PROCESS_WIDTH * process_height)
    motion_pixels = int(cv2.countNonZero(filtered_mask))
    motion_area_percent = (motion_pixels / total_pixels) * 100.0

    changed_delta = color_delta[filtered_mask > 0]
    if changed_delta.size:
        average_delta = float(changed_delta.mean())
        max_delta = float(changed_delta.max())
    else:
        average_delta = 0.0
        max_delta = 0.0

    global_change = motion_area_percent >= GLOBAL_CHANGE_PERCENT
    moving = bool(valid_contours) and not global_change

    payload = dict(base_payload)
    payload.update({
        "ready": True,
        "moving": moving,
        "globalChange": global_change,
        "motionAreaPercent": round(motion_area_percent, 4),
        "averageColorDelta": round(average_delta, 3),
        "maxColorDelta": round(max_delta, 3),
    })

    largest = None
    if valid_contours:
        largest = max(valid_contours, key=cv2.contourArea)
        target_area_percent = (float(cv2.contourArea(largest)) / total_pixels) * 100.0
        payload["targetAreaPercent"] = round(target_area_percent, 4)

    if moving and largest is not None:
        centroid, bbox = contour_target(cv2, largest, width, height, PROCESS_WIDTH, process_height)
        speed, direction = motion_speed_and_direction(state, centroid, captured_at)
        x_norm = (centroid["x"] / float(width)) * 2.0 - 1.0
        x_norm = max(-1.0, min(1.0, x_norm))
        bearing = "left" if x_norm < -0.2 else ("right" if x_norm > 0.2 else "center")
        payload.update({
            "centroid": centroid,
            "bbox": bbox,
            "speedPxPerSecond": round(speed, 2),
            "direction": direction,
            "x_norm": round(x_norm, 3),
            "bearing": bearing,
            "message": f"Motion {direction} at {speed:.1f} px/s",
        })
        state["previousMotionCentroid"] = centroid
        state["previousMotionTime"] = captured_at
        state["missedMotionFrames"] = 0
    else:
        state["missedMotionFrames"] += 1
        if state["missedMotionFrames"] > MOTION_MEMORY_FRAMES:
            state["previousMotionCentroid"] = None
            state["previousMotionTime"] = None

        if global_change:
            payload["message"] = "Global light or exposure change, not target motion"
            payload["direction"] = "global"
        else:
            payload["message"] = "No target motion"

    overlay = draw_overlay(cv2, frame.copy(), payload)
    return payload, overlay


def contour_target(cv2, contour, width, height, process_width, process_height):
    moments = cv2.moments(contour)
    x, y, w, h = cv2.boundingRect(contour)

    if moments["m00"] != 0:
        cx = moments["m10"] / moments["m00"]
        cy = moments["m01"] / moments["m00"]
    else:
        cx = x + (w / 2.0)
        cy = y + (h / 2.0)

    scale_x = width / float(process_width)
    scale_y = height / float(process_height)

    centroid = {
        "x": round(cx * scale_x, 2),
        "y": round(cy * scale_y, 2),
    }
    bbox = {
        "x": round(x * scale_x),
        "y": round(y * scale_y),
        "w": round(w * scale_x),
        "h": round(h * scale_y),
    }
    return centroid, bbox


def motion_speed_and_direction(state, centroid, captured_at):
    previous_centroid = state.get("previousMotionCentroid")
    previous_time = state.get("previousMotionTime")
    if previous_centroid is None or previous_time is None:
        return 0.0, "acquiring"

    dt = captured_at - previous_time
    if dt <= 0:
        return 0.0, "unknown"

    dx = centroid["x"] - previous_centroid["x"]
    dy = centroid["y"] - previous_centroid["y"]
    speed = math.sqrt((dx * dx) + (dy * dy)) / dt

    direction = direction_from_delta(dx, dy)
    return speed, direction


def direction_from_delta(dx, dy):
    deadzone = 3.0
    horizontal = ""
    vertical = ""

    if dx > deadzone:
        horizontal = "right"
    elif dx < -deadzone:
        horizontal = "left"

    if dy > deadzone:
        vertical = "down"
    elif dy < -deadzone:
        vertical = "up"

    if horizontal and vertical:
        return f"{vertical}-{horizontal}"
    if horizontal:
        return horizontal
    if vertical:
        return vertical
    return "steady"


def draw_overlay(cv2, frame, payload):
    moving = payload.get("moving", False)
    global_change = payload.get("globalChange", False)
    color = (126, 226, 184) if moving else (156, 174, 181)
    if global_change:
        color = (87, 200, 255)

    bbox = payload.get("bbox")
    if bbox:
        x = int(bbox["x"])
        y = int(bbox["y"])
        w = int(bbox["w"])
        h = int(bbox["h"])
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)

    centroid = payload.get("centroid")
    if centroid:
        cx = int(centroid["x"])
        cy = int(centroid["y"])
        cv2.circle(frame, (cx, cy), 6, color, -1)

    lines = [
        "MOVING" if moving else "LIGHT SHIFT" if global_change else "IDLE",
        f"speed {payload.get('speedPxPerSecond', 0):.1f} px/s {payload.get('direction', 'none')}",
        f"area {payload.get('motionAreaPercent', 0):.2f}% delta {payload.get('averageColorDelta', 0):.1f}",
        f"fps {payload.get('actualAnalysisFps', 0):.2f}/{TARGET_ANALYSIS_FPS:.0f} jitter {payload.get('lockJitterMs', 0):.1f}ms",
    ]

    y = 22
    for line in lines:
        cv2.putText(frame, line, (12, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 4, cv2.LINE_AA)
        cv2.putText(frame, line, (12, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 1, cv2.LINE_AA)
        y += 22

    return frame


def start_server():
    ThreadingHTTPServer.allow_reuse_address = True
    ThreadingHTTPServer.daemon_threads = True
    server = ThreadingHTTPServer((HOST, PORT), MotionHandler)
    print(f"MotionDetectionTest listening on http://{HOST}:{PORT}")
    server.serve_forever()


def shutdown(signum=None, frame=None):
    stop_motion_worker()
    raise SystemExit(0)


def start_parent_app():
    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    atexit.register(stop_motion_worker)

    restart_motion_worker("Initial motion worker start")
    threading.Thread(target=mission_loop, daemon=True).start()
    threading.Thread(target=start_server, daemon=True).start()

    def loop():
        time.sleep(1)

    App.run(user_loop=loop)


if WORKER_ARG in sys.argv:
    motion_worker_main()
else:
    start_parent_app()
